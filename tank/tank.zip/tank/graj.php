<?php
require_once 'connect.php';
//http://tank.iai.ninja/api/join-current-game.php
//$item = array('name' => 'filiżanka', 'price' => 23);
	//$item = json_encode($item);

$query="SELECT * from `tank` WHERE id=1";
				if($result= mysqli_query($link,$query)){
					if (mysqli_num_rows($result)==0) {
						
					}
					while ($data= mysqli_fetch_assoc($result)) {
						$key=$data['k_ey'];

					}}
					echo $key;
if($_GET['firedir'] != 0){
$dri=$_GET['firedir'];	
}else{
$dri=$_GET['move'];
//$dri=uper($dri);
}
echo $dri;
$dist=$_GET['dist'];
$fire=$_GET['fire'];
require_once 'move_up.php';
echo move($key,$dri,$dist,$fire);
?>