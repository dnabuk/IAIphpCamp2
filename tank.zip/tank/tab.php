<?php
$res='{"id":"5b3f1f8fa88474.64909589","name":"Game 2018-07-06 09:51","state":"waiting_for_moves","board":[{"type":"empty","position":"N8"},{"type":"empty","position":"D16"},{"type":"empty","position":"K17"},{"type":"empty","position":"E24"},{"type":"empty","position":"R7"},{"type":"empty","position":"B18"},{"type":"empty","position":"T12"},{"type":"empty","position":"J8"},{"type":"empty","position":"E14"},{"type":"empty","position":"I20"},{"type":"obstacle","position":"O11"},{"type":"empty","position":"Q6"},{"type":"empty","position":"R2"},{"type":"empty","position":"D14"},{"type":"empty","position":"W20"},{"type":"empty","position":"T6"},{"type":"empty","position":"L20"},{"type":"empty","position":"X7"},{"type":"empty","position":"H6"},{"type":"empty","position":"C1"},{"type":"empty","position":"E5"},{"type":"empty","position":"R17"},{"type":"empty","position":"L23"},{"type":"empty","position":"L22"},{"type":"empty","position":"I19"},{"type":"empty","position":"P8"},{"type":"empty","position":"S25"},{"type":"empty","position":"P25"},{"type":"empty","position":"V1"},{"type":"empty","position":"C16"},{"type":"empty","position":"N4"},{"type":"empty","position":"U2"},{"type":"empty","position":"R19"},{"type":"empty","position":"M2"},{"type":"empty","position":"S12"},{"type":"empty","position":"S3"},{"type":"empty","position":"I5"},{"type":"empty","position":"H8"},{"type":"empty","position":"W7"},{"type":"empty","position":"W18"},{"type":"empty","position":"J21"},{"type":"empty","position":"Q7"},{"type":"empty","position":"G1"},{"type":"empty","position":"F7"},{"type":"empty","position":"M19"},{"type":"empty","position":"I15"},{"type":"empty","position":"B9"},{"type":"empty","position":"C25"},{"type":"empty","position":"C9"},{"type":"empty","position":"M20"},{"type":"empty","position":"U1"},{"type":"empty","position":"G18"},{"type":"empty","position":"P21"},{"type":"empty","position":"T9"},{"type":"empty","position":"I24"},{"type":"empty","position":"L24"},{"type":"empty","position":"F23"},{"type":"empty","position":"W6"},{"type":"empty","position":"K19"},{"type":"empty","position":"U7"},{"type":"empty","position":"I13"},{"type":"empty","position":"O23"},{"type":"empty","position":"H15"},{"type":"empty","position":"E16"},{"type":"empty","position":"Y14"},{"type":"empty","position":"T4"},{"type":"empty","position":"P5"},{"type":"empty","position":"S17"},{"type":"obstacle","position":"V4"},{"type":"empty","position":"P4"},{"type":"empty","position":"E2"},{"type":"empty","position":"V18"},{"type":"empty","position":"U21"},{"type":"empty","position":"S7"},{"type":"obstacle","position":"P14"},{"type":"empty","position":"I12"},{"type":"empty","position":"I14"},{"type":"empty","position":"V25"},{"type":"empty","position":"R8"},{"type":"obstacle","position":"W4"},{"type":"empty","position":"X6"},{"type":"empty","position":"P17"},{"type":"empty","position":"L25"},{"type":"empty","position":"R15"},{"type":"empty","position":"N21"},{"type":"empty","position":"W9"},{"type":"empty","position":"X23"},{"type":"empty","position":"C5"},{"type":"empty","position":"M9"},{"type":"empty","position":"P1"},{"type":"empty","position":"M1"},{"type":"empty","position":"Y18"},{"type":"empty","position":"W13"},{"type":"empty","position":"C20"},{"type":"empty","position":"E9"},{"type":"empty","position":"F6"},{"type":"empty","position":"I23"},{"type":"empty","position":"O18"},{"type":"empty","position":"O21"},{"type":"empty","position":"X16"},{"type":"empty","position":"C10"},{"type":"empty","position":"O6"},{"type":"empty","position":"Y25"},{"type":"empty","position":"A1"},{"type":"empty","position":"E13"},{"type":"empty","position":"N17"},{"type":"obstacle","position":"O15"},{"type":"empty","position":"P6"},{"type":"empty","position":"C12"},{"type":"empty","position":"U8"},{"type":"empty","position":"H1"},{"type":"obstacle","position":"P16"},{"type":"empty","position":"Y11"},{"type":"empty","position":"B1"},{"type":"obstacle","position":"C4"},{"type":"empty","position":"Y6"},{"type":"empty","position":"I18"},{"type":"empty","position":"Q17"},{"type":"empty","position":"V10"},{"type":"empty","position":"D1"},{"type":"empty","position":"B22"},{"type":"obstacle","position":"V23"},{"type":"empty","position":"M18"},{"type":"empty","position":"F18"},{"type":"empty","position":"U17"},{"type":"empty","position":"F1"},{"type":"empty","position":"H19"},{"type":"empty","position":"Y16"},{"type":"empty","position":"O22"},{"type":"empty","position":"N7"},{"type":"empty","position":"U23"},{"type":"empty","position":"B25"},{"type":"empty","position":"R1"},{"type":"empty","position":"L7"},{"type":"empty","position":"C18"},{"type":"empty","position":"X25"},{"type":"empty","position":"U10"},{"type":"empty","position":"Y22"},{"type":"empty","position":"O8"},{"type":"empty","position":"F14"},{"type":"obstacle","position":"K15"},{"type":"empty","position":"U9"},{"type":"empty","position":"T19"},{"type":"empty","position":"I21"},{"type":"empty","position":"E4"},{"type":"obstacle","position":"J11"},{"type":"missile","position":"A21","direction":"s"},{"type":"empty","position":"S2"},{"type":"empty","position":"F2"},{"type":"empty","position":"X21"},{"type":"empty","position":"A24"},{"type":"empty","position":"L2"},{"type":"empty","position":"N1"},{"type":"empty","position":"I2"},{"type":"empty","position":"I17"},{"type":"empty","position":"P24"},{"type":"empty","position":"J9"},{"type":"empty","position":"V7"},{"type":"empty","position":"E18"},{"type":"empty","position":"U12"},{"type":"empty","position":"T24"},{"type":"empty","position":"K7"},{"type":"empty","position":"N19"},{"type":"empty","position":"L18"},{"type":"empty","position":"A4"},{"type":"empty","position":"W5"},{"type":"empty","position":"W17"},{"type":"obstacle","position":"W3"},{"type":"empty","position":"T14"},{"type":"empty","position":"C19"},{"type":"empty","position":"L4"},{"type":"empty","position":"H4"},{"type":"empty","position":"X17"},{"type":"empty","position":"C7"},{"type":"empty","position":"X22"},{"type":"empty","position":"K24"},{"type":"obstacle","position":"L13"},{"type":"empty","position":"V12"},{"type":"empty","position":"E1"},{"type":"empty","position":"T20"},{"type":"empty","position":"U16"},{"type":"empty","position":"T1"},{"type":"empty","position":"F10"},{"type":"empty","position":"X11"},{"type":"empty","position":"Y8"},{"type":"empty","position":"R6"},{"type":"empty","position":"K9"},{"type":"empty","position":"E23"},{"type":"empty","position":"R16"},{"type":"empty","position":"W2"},{"type":"empty","position":"H3"},{"type":"empty","position":"V17"},{"type":"empty","position":"S24"},{"type":"empty","position":"Y24"},{"type":"empty","position":"V11"},{"type":"empty","position":"I25"},{"type":"empty","position":"Q18"},{"type":"empty","position":"W11"},{"type":"empty","position":"G11"},{"type":"empty","position":"Y21"},{"type":"empty","position":"Y10"},{"type":"empty","position":"Q1"},{"type":"empty","position":"A25"},{"type":"empty","position":"V19"},{"type":"empty","position":"A18"},{"type":"empty","position":"Q9"},{"type":"empty","position":"A17"},{"type":"empty","position":"V24"},{"type":"empty","position":"V20"},{"type":"empty","position":"N24"},{"type":"empty","position":"U22"},{"type":"empty","position":"W25"},{"type":"empty","position":"W19"},{"type":"empty","position":"Q10"},{"type":"empty","position":"W16"},{"type":"empty","position":"H7"},{"type":"obstacle","position":"L11"},{"type":"empty","position":"O3"},{"type":"empty","position":"X12"},{"type":"empty","position":"U15"},{"type":"empty","position":"A6"},{"type":"empty","position":"H13"},{"type":"empty","position":"K22"},{"type":"empty","position":"Y13"},{"type":"empty","position":"A15"},{"type":"empty","position":"K18"},{"type":"empty","position":"G10"},{"type":"empty","position":"U18"},{"type":"empty","position":"D21"},{"type":"obstacle","position":"L15"},{"type":"empty","position":"U5"},{"type":"obstacle","position":"M16"},{"type":"empty","position":"Y7"},{"type":"empty","position":"K21"},{"type":"empty","position":"A3"},{"type":"empty","position":"D12"},{"type":"empty","position":"Q12"},{"type":"empty","position":"D6"},{"type":"empty","position":"O4"},{"type":"empty","position":"G4"},{"type":"empty","position":"Q5"},{"type":"empty","position":"E11"},{"type":"empty","position":"E25"},{"type":"empty","position":"H12"},{"type":"empty","position":"A22"},{"type":"empty","position":"D8"},{"type":"empty","position":"N2"},{"type":"empty","position":"E7"},{"type":"empty","position":"E15"},{"type":"empty","position":"T23"},{"type":"empty","position":"T16"},{"type":"empty","position":"R25"},{"type":"obstacle","position":"K16"},{"type":"empty","position":"A11"},{"type":"empty","position":"Q2"},{"type":"empty","position":"D9"},{"type":"empty","position":"P22"},{"type":"empty","position":"S11"},{"type":"empty","position":"J24"},{"type":"empty","position":"I7"},{"type":"empty","position":"N22"},{"type":"empty","position":"K8"},{"type":"obstacle","position":"O16"},{"type":"empty","position":"H23"},{"type":"empty","position":"I1"},{"type":"empty","position":"Q24"},{"type":"empty","position":"F16"},{"type":"obstacle","position":"D22"},{"type":"empty","position":"Q3"},{"type":"obstacle","position":"P15"},{"type":"empty","position":"M5"},{"type":"empty","position":"N18"},{"type":"empty","position":"Q23"},{"type":"empty","position":"E17"},{"type":"empty","position":"Q21"},{"type":"empty","position":"C8"},{"type":"empty","position":"G13"},{"type":"empty","position":"H14"},{"type":"player_base","position":"I4","name":null},{"type":"empty","position":"L8"},{"type":"empty","position":"S1"},{"type":"empty","position":"B4"},{"type":"empty","position":"R21"},{"type":"empty","position":"A7"},{"type":"empty","position":"D15"},{"type":"empty","position":"L3"},{"type":"obstacle","position":"P13"},{"type":"empty","position":"W8"},{"type":"empty","position":"G3"},{"type":"obstacle","position":"O12"},{"type":"empty","position":"Y23"},{"type":"empty","position":"T10"},{"type":"empty","position":"H25"},{"type":"empty","position":"O25"},{"type":"obstacle","position":"K13"},{"type":"obstacle","position":"M11"},{"type":"empty","position":"U20"},{"type":"empty","position":"F12"},{"type":"empty","position":"L5"},{"type":"empty","position":"Q16"},{"type":"empty","position":"Q11"},{"type":"empty","position":"X14"},{"type":"empty","position":"J3"},{"type":"empty","position":"H5"},{"type":"empty","position":"B3"},{"type":"empty","position":"G19"},{"type":"empty","position":"A2"},{"type":"empty","position":"N25"},{"type":"empty","position":"F5"},{"type":"obstacle","position":"M15"},{"type":"empty","position":"A14"},{"type":"empty","position":"X1"},{"type":"empty","position":"N3"},{"type":"empty","position":"P23"},{"type":"empty","position":"H9"},{"type":"empty","position":"V16"},{"type":"empty","position":"D10"},{"type":"obstacle","position":"M12"},{"type":"empty","position":"B15"},{"type":"empty","position":"K4"},{"type":"empty","position":"B10"},{"type":"empty","position":"G23"},{"type":"empty","position":"R14"},{"type":"empty","position":"R11"},{"type":"empty","position":"E12"},{"type":"empty","position":"X3"},{"type":"obstacle","position":"L12"},{"type":"empty","position":"R18"},{"type":"obstacle","position":"J13"},{"type":"empty","position":"E3"},{"type":"empty","position":"E8"},{"type":"obstacle","position":"O13"},{"type":"empty","position":"P9"},{"type":"empty","position":"R22"},{"type":"empty","position":"A23"},{"type":"empty","position":"T11"},{"type":"empty","position":"J22"},{"type":"empty","position":"G2"},{"type":"empty","position":"Q14"},{"type":"empty","position":"G5"},{"type":"empty","position":"M7"},{"type":"empty","position":"I3"},{"type":"empty","position":"D25"},{"type":"empty","position":"D11"},{"type":"empty","position":"S14"},{"type":"empty","position":"G25"},{"type":"empty","position":"T7"},{"type":"empty","position":"H21"},{"type":"empty","position":"U3"},{"type":"empty","position":"C21"},{"type":"empty","position":"Y3"},{"type":"empty","position":"G15"},{"type":"empty","position":"X2"},{"type":"empty","position":"H2"},{"type":"empty","position":"I22"},{"type":"obstacle","position":"J14"},{"type":"empty","position":"N9"},{"type":"empty","position":"T25"},{"type":"empty","position":"T3"},{"type":"empty","position":"U25"},{"type":"empty","position":"L1"},{"type":"empty","position":"T5"},{"type":"empty","position":"Y20"},{"type":"empty","position":"J19"},{"type":"empty","position":"D20"},{"type":"empty","position":"R20"},{"type":"empty","position":"X15"},{"type":"empty","position":"G7"},{"type":"empty","position":"O19"},{"type":"empty","position":"V8"},{"type":"obstacle","position":"V3"},{"type":"empty","position":"V21"},{"type":"empty","position":"J2"},{"type":"empty","position":"A8"},{"type":"empty","position":"N23"},{"type":"empty","position":"J23"},{"type":"empty","position":"O24"},{"type":"empty","position":"Y15"},{"type":"empty","position":"A19"},{"type":"empty","position":"F19"},{"type":"empty","position":"T13"},{"type":"empty","position":"S18"},{"type":"empty","position":"O1"},{"type":"empty","position":"H11"},{"type":"empty","position":"Q22"},{"type":"empty","position":"F21"},{"type":"empty","position":"U6"},{"type":"empty","position":"F17"},{"type":"empty","position":"X24"},{"type":"empty","position":"F8"},{"type":"empty","position":"T21"},{"type":"obstacle","position":"D3"},{"type":"empty","position":"U14"},{"type":"empty","position":"F20"},{"type":"empty","position":"Y1"},{"type":"empty","position":"E21"},{"type":"empty","position":"Q20"},{"type":"obstacle","position":"D4"},{"type":"empty","position":"O7"},{"type":"empty","position":"S19"},{"type":"empty","position":"M21"},{"type":"empty","position":"F15"},{"type":"empty","position":"S20"},{"type":"obstacle","position":"N11"},{"type":"empty","position":"G17"},{"type":"empty","position":"R4"},{"type":"obstacle","position":"W23"},{"type":"empty","position":"D18"},{"type":"empty","position":"B17"},{"type":"empty","position":"M6"},{"type":"empty","position":"H24"},{"type":"obstacle","position":"L10"},{"type":"empty","position":"F11"},{"type":"obstacle","position":"K10"},{"type":"obstacle","position":"K14"},{"type":"empty","position":"M3"},{"type":"empty","position":"I9"},{"type":"empty","position":"M25"},{"type":"empty","position":"S5"},{"type":"empty","position":"S16"},{"type":"empty","position":"O9"},{"type":"obstacle","position":"C23"},{"type":"empty","position":"G9"},{"type":"empty","position":"V6"},{"type":"empty","position":"S23"},{"type":"empty","position":"E10"},{"type":"obstacle","position":"O10"},{"type":"empty","position":"M8"},{"type":"empty","position":"R5"},{"type":"obstacle","position":"M13"},{"type":"empty","position":"F25"},{"type":"empty","position":"O17"},{"type":"empty","position":"C15"},{"type":"empty","position":"D5"},{"type":"empty","position":"L19"},{"type":"empty","position":"L21"},{"type":"empty","position":"F9"},{"type":"empty","position":"T17"},{"type":"obstacle","position":"J12"},{"type":"empty","position":"Y5"},{"type":"empty","position":"J4"},{"type":"empty","position":"S8"},{"type":"empty","position":"Q13"},{"type":"empty","position":"C2"},{"type":"empty","position":"P19"},{"type":"empty","position":"X9"},{"type":"empty","position":"V15"},{"type":"obstacle","position":"N12"},{"type":"empty","position":"F13"},{"type":"empty","position":"Y9"},{"type":"empty","position":"S9"},{"type":"obstacle","position":"V22"},{"type":"empty","position":"B20"},{"type":"empty","position":"P3"},{"type":"empty","position":"J1"},{"type":"empty","position":"F22"},{"type":"obstacle","position":"W22"},{"type":"empty","position":"V14"},{"type":"empty","position":"T15"},{"type":"empty","position":"C11"},{"type":"empty","position":"N20"},{"type":"empty","position":"P7"},{"type":"empty","position":"G21"},{"type":"empty","position":"I6"},{"type":"empty","position":"L17"},{"type":"empty","position":"H16"},{"type":"obstacle","position":"D23"},{"type":"empty","position":"H10"},{"type":"obstacle","position":"N14"},{"type":"empty","position":"W15"},{"type":"empty","position":"R9"},{"type":"empty","position":"G16"},{"type":"empty","position":"B2"},{"type":"empty","position":"F4"},{"type":"empty","position":"E6"},{"type":"empty","position":"Y2"},{"type":"empty","position":"E22"},{"type":"empty","position":"H20"},{"type":"obstacle","position":"P11"},{"type":"empty","position":"C13"},{"type":"empty","position":"S21"},{"type":"empty","position":"D17"},{"type":"empty","position":"J6"},{"type":"empty","position":"D19"},{"type":"empty","position":"U11"},{"type":"obstacle","position":"M14"},{"type":"empty","position":"H17"},{"type":"empty","position":"D7"},{"type":"empty","position":"R12"},{"type":"empty","position":"U4"},{"type":"obstacle","position":"K11"},{"type":"empty","position":"T2"},{"type":"empty","position":"S10"},{"type":"empty","position":"R24"},{"type":"obstacle","position":"L14"},{"type":"empty","position":"W21"},{"type":"empty","position":"R23"},{"type":"empty","position":"P20"},{"type":"obstacle","position":"N16"},{"type":"empty","position":"S13"},{"type":"empty","position":"B14"},{"type":"empty","position":"A16"},{"type":"empty","position":"U13"},{"type":"empty","position":"O5"},{"type":"empty","position":"T18"},{"type":"empty","position":"F3"},{"type":"empty","position":"B5"},{"type":"empty","position":"K6"},{"type":"empty","position":"G8"},{"type":"empty","position":"K5"},{"type":"empty","position":"V2"},{"type":"empty","position":"C14"},{"type":"empty","position":"D13"},{"type":"empty","position":"K23"},{"type":"empty","position":"R3"},{"type":"empty","position":"S15"},{"type":"empty","position":"J7"},{"type":"obstacle","position":"J16"},{"type":"empty","position":"X10"},{"type":"empty","position":"D24"},{"type":"empty","position":"K20"},{"type":"empty","position":"B12"},{"type":"empty","position":"J25"},{"type":"empty","position":"I8"},{"type":"empty","position":"A13"},{"type":"empty","position":"A12"},{"type":"empty","position":"A5"},{"type":"empty","position":"Q25"},{"type":"empty","position":"M23"},{"type":"empty","position":"J20"},{"type":"empty","position":"V5"},{"type":"empty","position":"P18"},{"type":"empty","position":"I16"},{"type":"empty","position":"T8"},{"type":"empty","position":"W12"},{"type":"empty","position":"M17"},{"type":"obstacle","position":"J15"},{"type":"obstacle","position":"C22"},{"type":"obstacle","position":"P10"},{"type":"empty","position":"B21"},{"type":"empty","position":"Y4"},{"type":"empty","position":"X5"},{"type":"empty","position":"G12"},{"type":"obstacle","position":"K12"},{"type":"empty","position":"Q19"},{"type":"empty","position":"Q4"},{"type":"obstacle","position":"M10"},{"type":"empty","position":"A9"},{"type":"empty","position":"X18"},{"type":"obstacle","position":"N10"},{"type":"empty","position":"G6"},{"type":"empty","position":"Y12"},{"type":"empty","position":"A20"},{"type":"empty","position":"R10"},{"type":"empty","position":"W24"},{"type":"obstacle","position":"N15"},{"type":"empty","position":"W10"},{"type":"empty","position":"B16"},{"type":"empty","position":"L9"},{"type":"empty","position":"G20"},{"type":"empty","position":"B8"},{"type":"empty","position":"J18"},{"type":"empty","position":"V9"},{"type":"empty","position":"F24"},{"type":"empty","position":"S4"},{"type":"empty","position":"S6"},{"type":"empty","position":"N6"},{"type":"empty","position":"B24"},{"type":"empty","position":"L6"},{"type":"empty","position":"Q15"},{"type":"empty","position":"I10"},{"type":"player","position":"O2","name":"killer"},{"type":"empty","position":"C24"},{"type":"empty","position":"X8"},{"type":"obstacle","position":"N13"},{"type":"empty","position":"D2"},{"type":"empty","position":"O20"},{"type":"empty","position":"K1"},{"type":"empty","position":"U19"},{"type":"obstacle","position":"P12"},{"type":"empty","position":"B19"},{"type":"empty","position":"P2"},{"type":"obstacle","position":"J10"},{"type":"empty","position":"A10"},{"type":"empty","position":"N5"},{"type":"empty","position":"Y19"},{"type":"empty","position":"B23"},{"type":"empty","position":"T22"},{"type":"empty","position":"J5"},{"type":"empty","position":"M24"},{"type":"empty","position":"X13"},{"type":"empty","position":"X20"},{"type":"empty","position":"X4"},{"type":"empty","position":"U24"},{"type":"empty","position":"W14"},{"type":"empty","position":"G22"},{"type":"obstacle","position":"C3"},{"type":"empty","position":"C6"},{"type":"empty","position":"K2"},{"type":"empty","position":"R13"},{"type":"empty","position":"E19"},{"type":"empty","position":"B6"},{"type":"empty","position":"G24"},{"type":"obstacle","position":"O14"},{"type":"empty","position":"M4"},{"type":"empty","position":"C17"},{"type":"empty","position":"E20"},{"type":"empty","position":"B11"},{"type":"empty","position":"B13"},{"type":"empty","position":"M22"},{"type":"empty","position":"I11"},{"type":"empty","position":"W1"},{"type":"empty","position":"G14"},{"type":"player","position":"B7","name":"Team_5"},{"type":"empty","position":"H22"},{"type":"empty","position":"K3"},{"type":"empty","position":"K25"},{"type":"empty","position":"S22"},{"type":"obstacle","position":"L16"},{"type":"empty","position":"J17"},{"type":"empty","position":"H18"},{"type":"empty","position":"X19"},{"type":"empty","position":"Y17"},{"type":"empty","position":"Q8"},{"type":"empty","position":"V13"}],"turnNumber":55,"players":[{"name":"killer","score":0},{"name":"Team_5","score":0}],"settings":{"boardSize":25,"speed":10000,"missleSpeed":3,"missleRange":3,"pointsForPlayer":1,"pointsForPlayersBase":1,"winningScore":10,"maximumRoundsNumber":0,"maxMoveDistance":2}}';
$curl=curl_init('http://tank.iai.ninja/api/get-current-board.php');
	curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($curl, CURLOPT_POST, true);
	curl_setopt($curl, CURLOPT_CUSTOMREQUEST, 'GET');
	//curl_setopt($curl, CURLOPT_POSTFIELDS, $item);
	$result=curl_exec($curl);
	//var_dump(json_decode($result,true));
	$dane=json_decode($result,true);
$i=0;

	foreach ($dane['board'] as $key3 => $value) {
		if($value['type'] == 'missile'){
			//echo $value['position'];
			//echo $value['direction'];

		}else if ($value['type'] == 'obstacle') {
			$przesz[]=$value['position'];

			//echo $value['position'];
		}else if($value['type'] == 'player' && $value['name']=='grupa_3'){
			$my_postion=$value['position'];
			//echo $value['position'];
		}else if($value['type'] == 'player' && $value['name']!='grupa_3'){
			$player_postion=$value['position'];
			//echo $value['position'];
		}
		if($value['type'] == 'player_base' && $value['name']!='grupa_3'){
			$target=$value['position'];
			//echo $value['position'];
			}
		}
		$target=str_split($target);
		if(count($target)==3){
		$target[1]=$target[1].$target[2];
	}
while ($i <= 3000) {
$curl=curl_init('http://tank.iai.ninja/api/get-current-board.php');
	curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($curl, CURLOPT_POST, true);
	curl_setopt($curl, CURLOPT_CUSTOMREQUEST, 'GET');
	//curl_setopt($curl, CURLOPT_POSTFIELDS, $item);
	$result=curl_exec($curl);
	//var_dump(json_decode($result,true));
	$dane=json_decode($result,true);
require_once 'connect.php';
//http://tank.iai.ninja/api/join-current-game.php
//$item = array('name' => 'filiżanka', 'price' => 23);
	//$item = json_encode($item);

$query="SELECT * from `tank` WHERE id=1";
				if($result= mysqli_query($link,$query)){
					if (mysqli_num_rows($result)==0) {
						
					}
					while ($data= mysqli_fetch_assoc($result)) {
						$key=$data['k_ey'];

					}}
					echo $key;

	foreach ($dane['board'] as $key3 => $value) {
		if($value['type'] == 'missile'){
			//echo $value['position'];
			//echo $value['direction'];

		}else if ($value['type'] == 'obstacle') {
			$przesz[]=$value['position'];

			//echo $value['position'];
		}else if($value['type'] == 'player' && $value['name']=='grupa_3'){
			$my_postion=$value['position'];
			//echo $value['position'];
		}else if($value['type'] == 'player' && $value['name']!='grupa_3'){
			$player_postion=$value['position'];
			//echo $value['position'];
		}
		if($value['type'] == 'player_base' && $value['name']!='grupa_3'){
			//$target=$value['position'];
			//echo $value['position'];
			}
		}
		//$target=str_split($target);
		$my_postion=str_split($my_postion);
//echo $my_postion;
$lit=range('A','Z');
$lit2=array('AA','AB','AC','AD');
$lit=array_merge($lit,$lit2);
$num=range(1, 30);
require_once 'move_up.php';
var_dump($target);
var_dump($my_postion);


foreach ($num as $key2 => $value) {
	//echo move($key,'w',1,0);
	//sleep(1.2);
}


	$i++;
	echo $target[0];
	echo $my_postion[0];
	echo $target[1];
	echo $my_postion[1];
	if(count($my_postion)==3){
		$my_postion[1]=$my_postion[1].$my_postion[2];
	}
	if(count($target)==3){
		//$target[1]=$target[1].$target[2];
	}
	if($target[0]!=$my_postion[0]){
	if(((ord($target[0]))-(ord($my_postion[0])))<1){
echo 'ruch w';
	echo move($key,'w',1,0);
	sleep(0.1);
}else{
echo move($key,'e',1,0);
echo 'ruch s';
sleep(0.1);
}
	}else{
if(abs($target[1]-$my_postion[1])<=9){

	if(($target[1]-$my_postion[1])<0){
		echo move($key,'n',1,1);
		die();
	}else{
echo move($key,'s',1,1);
die();
	}

}else{
if(($target[1]-$my_postion[1])<0){
		echo move($key,'n',1,0);
	}else{
echo move($key,'s',1,0);

	}


}
		
	}
}



?>